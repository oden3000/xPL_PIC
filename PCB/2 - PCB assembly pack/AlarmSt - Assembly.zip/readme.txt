Created with Eagle v4.16 by Bogdan Negoescu - nbogdan21@yahoo.com

All gerber files are not mirrored. Format is 274x.

<<Solderpaste>>
 
.crs - gerber solder side cream mask stencil

<<BOM>>

.xls - Excel BOM file

<<Coordinates>>

.mnt - text placement file for parts (positive coordinates, tab separated)

<<Documentation>>

doc_top.pdf - placement drawing for top side
doc_bot.pdf - placement drawing for bottom side

-END-