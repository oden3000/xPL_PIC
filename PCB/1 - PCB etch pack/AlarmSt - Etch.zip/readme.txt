Created by Bogdan Negoescu - nbogdan21@yahoo.com

All gerber files are not mirrored. Format is 274x.

<<Copper>>

.cmp - gerber component side (top)
.sol - gerber solder side (bottom)

<<Drilling>>

.drd - excellon drill data (diameters in inch)

<<Solderstop>>

.stc - gerber component side solder mask
.sts - gerber solder side solder mask

<<Silkscreen>>

.plc - gerber component side silkscreen
.pls - gerber solder side silkscreen

-END-